package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editTextUserName;
    EditText editTextPassword;
    EditText editTextRetypePassword;

    Button signup;
    Button signin;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.editTextUserName = findViewById(R.id.editTextUserName);
        this.editTextPassword = findViewById(R.id.editTextPassword);
        this.editTextRetypePassword = findViewById(R.id.editTextRetypePassword);
        this.signup = findViewById(R.id.buttonRegister);
        this.signin = findViewById(R.id.buttonLogin);
        this.db = new DBHelper(this);
    }

    public void onSignup(View view) {
//        Intent login = new Intent("com.example.loginapp.LoginActivity");
//        Intent loginIntent = new Intent(getApplicationContext(), LoginActivity.class);
//        startActivity(loginIntent);

        String userName = editTextUserName.getText().toString();
        String password = editTextPassword.getText().toString();
        String repassword = editTextRetypePassword.getText().toString();

        if (userName.equals("") || password.equals("") || repassword.equals("")) {
            Toast.makeText(MainActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
        } else if (password.equals(repassword)) {
            Boolean checkuser = db.checkusername(userName);
            if (checkuser == false) {
                Boolean insert = db.insertData(userName, password);
                if (insert == true) {
                    Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(MainActivity.this, "User already exists! Please Login", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Passwords not Matching", Toast.LENGTH_SHORT).show();
        }
    }
    public void onSignin(View view) {
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);

    }
}