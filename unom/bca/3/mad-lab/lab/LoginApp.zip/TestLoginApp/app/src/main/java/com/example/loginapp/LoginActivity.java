package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {


    EditText editTextUserName;
    EditText editTextPassword;
    EditText editTextRetypePassword;

    Button buttonLogin;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        this.editTextUserName = findViewById(R.id.editTextUserName);
        this.editTextPassword = findViewById(R.id.editTextPassword);

        this.buttonLogin = findViewById(R.id.buttonLogin);
        this.db = new DBHelper(this);
    }

    public void onLogin(View view) {

        String user = editTextUserName.getText().toString();
        String pass = editTextPassword.getText().toString();

        if (user.equals("") || pass.equals("")) {
            Toast.makeText(LoginActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
        } else {
            Boolean checkuserpass = db.checkusernamepassword(user, pass);
            if (checkuserpass == true) {
                Toast.makeText(LoginActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), HomeScreenActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        }


//        Intent login = new Intent("com.example.loginapp.HomeScreenActivity");
//        startActivity(login);
    }
}